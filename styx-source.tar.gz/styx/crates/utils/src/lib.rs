// Placeholder for skypilot-utils
