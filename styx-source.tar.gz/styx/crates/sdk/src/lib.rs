// Placeholder for skypilot-sdk
